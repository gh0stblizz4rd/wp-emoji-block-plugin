# Emoji Display Block

A simple Wordpress [Gutenberg editor](https://wordpress.org/gutenberg/) block used to display users chosen emoji. The emoji selector window is created using [emoji-picker-react](https://github.com/ealush/emoji-picker-react) component made by @ealush.

## How to use?

After instalation of the plugin open the block editor of any post or page.
[](https://i.imgur.com/GUlDfYZ.png)
